#include<iostream>
#include<string>
#include<fstream>
#include<random>
#include"json.hpp"
#include"windows.h"
#include"urlmon.h"

using json = nlohmann::json;
using namespace std;
bool DownloadFile(const char* url, const char* file)
{
    return URLDownloadToFileA(NULL, url, file, 0, NULL) == S_OK;
}

json j;

pair<string,string> getRandomUma(int i)
{
    ifstream infile("./playerdatabase/playersDB.json");
    if (!infile.is_open())
    {
        cerr << "Failed to open file." << endl;
        return make_pair("", "");
    }
    infile >> j;
    infile.close();

    // Check if players array exists and has the required index
    if (!j.contains("players") || i >= j["players"].size())
    {
        cerr << "Invalid player index: " << i << endl;
        return make_pair("", "");
    }

    random_device rd;
    mt19937 gen(rd());

    string playerName = j["players"][i]["name"];
    
    if (!j["players"][i].contains("uma") || j["players"][i]["uma"].empty())
    {
        cerr << "No uma data for player: " << i << endl;
        return make_pair("", "");
    }

    uniform_int_distribution<int> disUma(0, j["players"][i]["uma"].size() - 1);
    int randomUmaIndex = disUma(gen);
    string umaName = j["players"][i]["uma"][randomUmaIndex];

    return make_pair(playerName, umaName);
}

int main()
{   
    const char* url = 
    
            "https://raw.githubusercontent.com/FuruMi06/playerDB/refs/heads/main/playersDB.json";

    if(DownloadFile(url, "./playerdatabase/playersDB.json"))
    {
        cout << "Download successful." << endl;
    }
    else
    {
        cout << "Download failed." << endl;
        return 1;
    }
    
    // Load the JSON file
    ifstream infile("./playerdatabase/playersDB.json");
    infile >> j;
    int SIZE = j["players"].size();
    infile.close();

    cout << "Total Players: " << SIZE << endl<<endl;
    for(int i = 0; i < SIZE; i++)
    {
        pair<string,string> r = getRandomUma(i);
        cout << "Player\t: " << r.first << "\nUma\t: " << r.second << endl<<endl;     
    }
    cin.get();
    return 0;  
}